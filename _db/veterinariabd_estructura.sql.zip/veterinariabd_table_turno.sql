
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turno`
--

CREATE TABLE `turno` (
  `ID_Turno` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `ID_Mascota` int(11) NOT NULL,
  `ID_Empleado` int(11) NOT NULL,
  `ID_Tipo_Turno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `turno`:
--   `ID_Empleado`
--       `empleado` -> `ID_Empleado`
--   `ID_Mascota`
--       `mascota` -> `ID_Mascota`
--   `ID_Tipo_Turno`
--       `tipo_turno` -> `ID_Tipo_Turno`
--
