
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_venta`
--

CREATE TABLE `detalle_venta` (
  `ID_Detalle_Venta` int(11) NOT NULL,
  `ID_Venta` int(11) NOT NULL,
  `ID_Producto` int(11) NOT NULL,
  `ID_Tipo_Producto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACIONES PARA LA TABLA `detalle_venta`:
--   `ID_Producto`
--       `producto` -> `ID_Producto`
--   `ID_Tipo_Producto`
--       `tipo_producto` -> `ID_Tipo_Producto`
--   `ID_Venta`
--       `venta` -> `ID_Venta`
--
