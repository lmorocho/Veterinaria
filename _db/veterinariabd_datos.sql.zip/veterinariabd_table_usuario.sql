
--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID_Usuario`, `Nombre_Usuario`, `Password`, `ID_Rol`) VALUES
(1, 'lmorocho', '123', 1),
(2, 'mpgaray', '123', 1),
(3, 'atoneguzzi', '123', 1),
(4, 'aarufe', '123', 1),
(7, 'templeado', '123', 2),
(8, 'tcliente', '123', 3),
(9, 'admin', '123', 1),
(10, 't2cliente', '123', 3),
(11, 'jaempleado', '123', 2),
(14, 'cliente4', '123', 3),
(15, 'empleado3', '123', 2);
