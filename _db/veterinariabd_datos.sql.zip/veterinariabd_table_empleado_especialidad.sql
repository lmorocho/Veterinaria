
--
-- Volcado de datos para la tabla `empleado_especialidad`
--

INSERT INTO `empleado_especialidad` (`ID_ESP_EMP`, `ID_Empleado`, `ID_Especialidad`) VALUES
(1, 9, 1),
(2, 10, 2),
(3, 11, 3);
