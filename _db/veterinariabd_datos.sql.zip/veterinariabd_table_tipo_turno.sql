
--
-- Volcado de datos para la tabla `tipo_turno`
--

INSERT INTO `tipo_turno` (`ID_Tipo_Turno`, `Nombre_Tipo_Turno`) VALUES
(1, 'Revisión General de Mascota'),
(2, 'Vacunas Mascota'),
(3, 'Spa para Mascota');
