
--
-- Volcado de datos para la tabla `especialidad`
--

INSERT INTO `especialidad` (`ID_Especialidad`, `Nombre_Especialidad`) VALUES
(1, 'Revisión General de Mascota'),
(2, 'Vacunas Mascota'),
(3, 'Spa para Mascota');
