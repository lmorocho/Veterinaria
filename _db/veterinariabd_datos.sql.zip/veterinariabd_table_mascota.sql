
--
-- Volcado de datos para la tabla `mascota`
--

INSERT INTO `mascota` (`ID_Mascota`, `Nombre`, `Fecha_Nacimiento`, `ID_Raza`, `ID_Cliente`) VALUES
(5, 'pippo', '2022-01-02', 3, 4),
(6, 'blacky', '2020-01-10', 1, 2),
(9, 'bet', '2023-12-11', 9, 2),
(10, 'blacky', '2023-01-01', 2, 2),
(11, 'pippo', '2020-02-10', 4, 2),
(12, 'bet2', '2021-12-25', 8, 2),
(13, 'bet', '2022-10-01', 8, 4),
(15, 'dan', '2024-12-05', 4, 7);
