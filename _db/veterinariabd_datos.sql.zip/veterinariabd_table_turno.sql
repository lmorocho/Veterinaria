
--
-- Volcado de datos para la tabla `turno`
--

INSERT INTO `turno` (`ID_Turno`, `Fecha`, `Hora`, `ID_Mascota`, `ID_Empleado`, `ID_Tipo_Turno`) VALUES
(4, '2025-06-16', '09:00:00', 15, 5, 1);
